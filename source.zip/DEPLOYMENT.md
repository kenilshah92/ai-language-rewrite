# Deploy the private app

The app is prepared for one private server shared by you and a small team. It is not deployed yet. Docker is not installed on the development Mac, so the container build must be verified on the hosting service or another machine with Docker before rollout.

## Recommended route: Render

Deploy release 0.3.0 from the current source package. It includes the paragraph-first PDF workflow, the configured humanizer/Wikipedia writing guidance, two bounded repair rounds, model selection, and proposal/final-text audit reports. Complex mixed-style or disconnected PDF blocks remain unchanged with an explicit report entry. The same Python engine runs locally and in the container; hosting requires no rewrite of the application.

1. Create a **private GitHub repository** and upload only the application source, requirements.txt, Dockerfile, render.yaml, settings/humanizer-prompt.md, tests, and documentation. Do not upload `.env`, uploads, output, tmp, .venv, or customer presentations. `.dockerignore` only permits app source, requirements, and the writing prompt into the container image.
2. In Render, create a **Web Service** from the private repository and select the **Docker** runtime. Use an always-on paid instance for document processing; choose its size and confirm current pricing in the dashboard. The included `render.yaml` is an optional Blueprint configuration using the Starter plan. Larger PDFs may require a larger instance.
3. Add a **secret file** named `.env` in the service settings. Render mounts it at `/etc/secrets/.env`, which the app loads. Enter these values there, never in GitHub or chat:

   ```dotenv
   OPENAI_API_KEY=your-key
   OPENAI_MODEL=gpt-6-astra
   ALLOWED_MODELS=gpt-6-astra,gpt-5.6-sol,gpt-5.6-terra,gpt-5.6-luna
   APP_USERNAME=your-team-login
   APP_PASSWORD=use-a-unique-random-password-at-least-16-characters
   FILE_RETENTION_HOURS=24
   MAX_UPLOAD_MB=50
   MIN_FONT_SCALE=0.85
   ```

4. The Docker image sets `APP_HOSTED=true` and `DATA_DIR=/data`. Keep those settings. Hosted startup refuses missing credentials or a password shorter than 16 characters. Set the health-check path to `/api/health`. Run exactly one application process/instance because job state is currently held in memory.
5. Deploy. The service should expose an HTTPS URL such as `https://your-service.onrender.com`. Open it and sign in using the shared credentials. Test one small PDF, DOCX, and TXT file; verify downloads and reports before sharing the URL with your team.
6. Share the URL and password separately. API calls are billed to the owner of the key. Model access depends on that API account, independently of a ChatGPT or Codex subscription.

Render documentation: https://render.com/docs/deploy-docker and https://render.com/docs/configure-environment-variables

## Storage and privacy

Locally, files stay on the Mac. On a hosted instance, files are uploaded to the server; only extracted text and its text context go to the OpenAI API. There is no app telemetry or external file-storage integration. Hosting-provider request logs are separate from the app.

Hosted files expire after the configured retention period, with cleanup every five minutes and at startup. Zero disables cleanup and should only be used locally. Render ephemeral storage also disappears on restart/redeploy. Download results promptly. Running jobs are not resumed after a restart, and status is not durable. The process handles two rewrites at a time and admits up to eight uploads/queued/running jobs. It is a small-team deployment, not a horizontally scaled or public SaaS service.

All app routes, API configuration, job status, and downloads require the shared login in hosted mode; only the minimal health endpoint is public. This is a shared team account, without per-person file isolation, invitations, or individual audit trails. HTTPS is provided by the host and is required. Do not expose plain HTTP directly on the public internet.

## Change the model

Set `OPENAI_MODEL` to the default API model ID. Set `ALLOWED_MODELS` to a comma-separated list of API model IDs available to your account; these appear in the model selector. Save the secret `.env` and restart/redeploy the service. Model choice changes text generation, cost, and time, but cannot repair layout or font limitations. The app preserves the selected model in each report.

## Other container hosts

The same image can run on a container service or VM with HTTPS termination. Supply a readable secret `.env` at `/etc/secrets/.env`, a writable `/data` directory for UID 10001, and `PORT` if the platform requires a custom port. Keep one Uvicorn worker. Example Docker verification on a machine with Docker:

```sh
docker build -t ai-language-rewrite .
docker run --rm -p 127.0.0.1:8000:8000 --mount type=bind,src=/absolute/path/to/hosted.env,dst=/etc/secrets/.env,readonly ai-language-rewrite
```

Use a separate hosted secret file; do not copy a local `APP_HOSTED=false` or `FILE_RETENTION_HOURS=0` configuration into production.

## Release checks

```sh
python -m pytest -q
PYTHONPATH=. python scripts/smoke_test.py
```

Before a broader rollout, add individual accounts, durable job storage/queueing, provider resource monitoring, and a documented backup/deletion policy. These are future capabilities, not included features.
